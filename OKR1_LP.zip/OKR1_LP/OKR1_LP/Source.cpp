#include <iostream>
#include <windows.h>
#include <gdiplus.h>
#include <stdio.h>
#include <conio.h>
using namespace Gdiplus;
#pragma comment (lib,"Gdiplus.lib")

const double Pi = 3.1415926535897932384;
class MathPoint
{
public:
	static Point Range2Point(Point pointFrom, Point pointTo)
	{
		Point p;
		p.X = pointTo.X - pointFrom.X;
		p.Y = pointTo.Y - pointFrom.Y;
		return p;
	}
	static Point avgA(Point* points, int countPoints)
	{
		Point* p = new Point();

		for (int i = 0; i < countPoints; i++)
		{
			p->X += points[i].X;
			p->Y += points[i].Y;
		}

		p->X /= countPoints;
		p->Y /= countPoints;

		return *p;
	}

	static double DegreeToRad(double degree) { return degree * Pi / 180; }


	static Point RotationByPoint(Point pointO, Point point, double degree)
	{
		Point p;

		degree = DegreeToRad(degree);

		p.X = pointO.X + (point.X - pointO.X) * cos(degree) - (point.Y - pointO.Y) * sin(degree);
		p.Y = pointO.Y + (point.X - pointO.X) * sin(degree) + (point.Y - pointO.Y) * cos(degree);

		return p;
	}
};

class Window
{
private:

protected:
	HWND hWnd;
	HDC hDC;
	GdiplusStartupInput gdiplusStartupInput;
	ULONG_PTR gdiplusToken;

public:
	Window()
	{
		GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);
		hWnd = GetConsoleWindow();
		hDC = GetDC(hWnd);
	}
	void Clear()
	{
		InvalidateRect(hWnd, 0, TRUE);
		UpdateWindow(hWnd);
	}
};

class Shape : public Window, public MathPoint
{
private:
	Point* m_Point;
	DOCINFO docInfo;
	bool PrintOver;
	Point m_OP;
	double m_Degree;
protected:
	int SizeArrayPrint;
public:
#pragma region Init
	Shape()
	{
		PrintOver = false;
		m_Degree = 0;

		ZeroMemory(&docInfo, sizeof(docInfo));
		docInfo.cbSize = sizeof(docInfo);
		docInfo.lpszDocName = L"GdiplusPrint";

		StartDoc(hDC, &docInfo);
	};
	~Shape()
	{
		EndDoc(hDC);
		GdiplusShutdown(gdiplusToken);
	}

	void InitShape()
	{
		m_Point = new Point[SizeArrayPrint + 1];
	}

	void SetStateItem(Point arr, int index)
	{
		if (index >= 0 && index <= SizeArrayPrint)
			m_Point[index] = arr;
	}
#pragma endregion

#pragma region Print
	void Print()
	{
		if (SizeArrayPrint > 0)
		{
			m_Point[SizeArrayPrint] = m_Point[0];
			StartPage(hDC);

			Graphics* graphics = new Graphics(hDC);
			Pen* pen = new Pen(Color(Color::White));
			if (PrintOver)
			{
				GraphicsPath* path = new GraphicsPath();
				path->AddLines(m_Point, SizeArrayPrint + 1);
				graphics->FillPath(new SolidBrush(Color::White), path);
			}
			else
				graphics->DrawLines(pen, m_Point, SizeArrayPrint + 1);

			delete pen;
			delete graphics;

			EndPage(hDC);
		}
	}
#pragma endregion

#pragma region Func
	Point MidShape()
	{
		m_OP = avgA(m_Point, SizeArrayPrint);
		return m_OP;
	}
	double DegreeShape() { return m_Degree; }
	void Move(int x, int y)
	{
		for (int i = 0; i < SizeArrayPrint; i++)
		{
			m_Point[i].X += x;
			m_Point[i].Y += y;
		}
	}
	void Rotate(double degree)
	{
		m_Degree += degree;
		MidShape();

		for (int i = 0; i < SizeArrayPrint; i++)
		{
			m_Point[i] = RotationByPoint(m_OP, m_Point[i], degree);
		}
	}
	void Cliar()
	{
		Clear();
	}
	void PaintOver(bool printOver)
	{
		PrintOver = printOver;
	}
#pragma endregion
};

class Trapezoid : public Shape
{
private:
	int m_Base;
	int LeftSide;
	int RightSide;

	int LeftAngle;
	int RightAngle;

	Point StartPoint;

private:
	void SetPoints()
	{
		SetStateItem(StartPoint, 0);

		Point point;
		point.X = StartPoint.X + m_Base;
		point.Y = StartPoint.Y;
		SetStateItem(point, 1);

		Point point1 = point;
		point.X = point.X - RightSide;
		point.Y = point.Y;
		point = RotationByPoint(point1, point, RightAngle);
		SetStateItem(point, 2);


		point.X = StartPoint.X + LeftSide;
		point.Y = StartPoint.Y;
		point = RotationByPoint(StartPoint, point, RightAngle * -1);
		SetStateItem(point, 3);

	}
public:
#pragma region Init
	Trapezoid()
	{
		SizeArrayPrint = 4;
		InitShape();
		StartPoint.X = StartPoint.Y = 100;
	}

	Trapezoid(int startPointX, int startPointY)
	{
		SizeArrayPrint = 4;
		InitShape();
		StartPoint.X = startPointX;
		StartPoint.Y = startPointY;
	}

	void Init(int base, int leftSide, int rightSide, int leftAngle, int rightAngle)
	{
		m_Base = base;
		LeftAngle = leftAngle;
		RightAngle = rightAngle;
		LeftSide = leftSide;
		RightSide = rightSide;
		SetPoints();
	}
#pragma endregion

#pragma region Func	
	void EditSize(int base, int leftSide, int rightSide, int leftAngle, int rightAngle)
	{
		Point p = MidShape();
		double d = DegreeShape();

		m_Base = base;
		LeftAngle = leftAngle;
		RightAngle = rightAngle;
		LeftSide = leftSide;
		RightSide = rightSide;

		SetPoints();

		Point p1 = MidShape();

		Point point = Range2Point(p1, p);

		Move(point.X, point.Y);
		Rotate(d);
	}
#pragma endregion	
};

int main()
{
	while (true)
	{
		Trapezoid t(500, 150);
		t.Init(100, 50, 50, 60, 60);
		
		Sleep(10);
		t.Print();

		Sleep(1000);

		t.Cliar();
		Sleep(1000);

		t.PaintOver(true);
		t.Print();
		Sleep(1000);

		t.Move(300, 0);
		t.Cliar();
		Sleep(10);
		t.Print();
		Sleep(1000);
		
		t.Rotate(5);
		t.Cliar();
		Sleep(10);
		t.Print();
		Sleep(1000);

		t.EditSize(200, 100, 100, 60, 60);
		t.Cliar();
		Sleep(10);
		t.Print();
		Sleep(1000);

		t.Cliar();
	}
	return 0;
}

