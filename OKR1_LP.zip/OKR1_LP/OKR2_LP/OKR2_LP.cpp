﻿#include <iostream>
using namespace std;

class Matrix
{
private:
	double** mas;
	int N, M;

public:
	Matrix()
	{

	}
	Matrix(int n, int m)
	{
		N = n;
		M = m;
		mas = new double* [n]; //казываем масив
		for (int i = 0; i < n; i++) //водим значение матрицы
		{
			mas[i] = new double[m]; //для того чтобы в стону можно было вести m количество значений
		}
	}

	double* operator [](int index1)//, int index2)
	{
		return mas[index1];
	}

	friend istream& operator >> (istream& is, Matrix& r)
	{
		for (int i = 0; i < r.N; i++)
		{
			for (int j = 0; j < r.M; j++)
			{
				cout << "Введите значение ечейки в строке:  " << i << ", столбце: " << j << " ";
				is >> r[i][j];
			}
		}
		return is;
	}

	friend ostream& operator << (ostream& is, Matrix& r)
	{
		for (int i = 0; i < r.N; i++)
		{
			for (int j = 0; j < r.M; j++)
			{
				is << r[i][j] << "\t";
			}
			is << endl;
		}
		return is;
	}

	double self_value(int i, int j)
	{
		if (i < N - 1 && i > 0 && j < M - 1 && j > 0)
		{
			return mas[i][i];
		}
		return LONG_MAX;
	}

	double* self_vactor(int i)
	{
		if (i < N - 1 && i > 0)
		{
			return mas[i];
		}
		return new double[1]{ LONG_MAX };
	}

	void reverse()
	{
		Matrix m(N, M);
		for (int i = 0, ii = N - 1; i < N || ii > 0; i++, ii--)
		{
			for (int j = 0, jj = M - 1; j < M || jj > 0; j++, jj--)
			{
				m[ii][jj] = mas[i][j];
			}
		}

		*this = m;
	}
};
int main()
{
	setlocale(LC_ALL, "Rus");

	int n, m, e, r;
	cout << "Введите высоту: ";
	cin >> n;
	cout << "Введите ширину: ";
	cin >> m;
	Matrix M1(n, m);
	cin >> M1;
	cout << endl;
	cout << M1;
	cout << endl;
	double aaa = M1[1][1];
	cout << "item [1][1]: " << aaa << endl;

	cout << endl;
	cout << "reverse()" << endl;
	M1.reverse();
	cout << M1;

	cout << endl;
	cout << "self_value([1][1])" << endl;
	double item = M1.self_value(1, 1);
	cout << item;

	cout << endl;
	cout << "self_vector[1])" << endl;
	auto item1 = M1.self_vactor(1);
	for (int i = 0; i < m; i++)
	{
		cout << item1[i];
	}
	cout << endl;
	system("pause");
	return 0;
}
