﻿#include <iostream>
using namespace std;

class Matrix
{
private:
	double** mas;
	Matrix sum(Matrix M2)
	{
		if (M == M2.M && N == M2.N)
		{
			Matrix rez(N, M);
			for (int i = 0; i < N; i++) //строки(цикл)
			{
				for (int j = 0; j < M; j++) //столцы(цикл)
				{
					rez.mas[i][j] = mas[i][j] + M2.mas[i][j];
				}

			}
			return rez;
		}
		else
		{
			cout << "Ошибка! Не совподают размерности матриц!";
			return Matrix(0, 0);
		}

	}
	Matrix sub(Matrix M2)
	{
		if (M == M2.M && N == M2.N)
		{
			Matrix rez(N, M);
			for (int i = 0; i < N; i++) //строки(цикл)
			{
				for (int j = 0; j < M; j++) //столцы(цикл)
				{
					rez.mas[i][j] = mas[i][j] - M2.mas[i][j];
				}

			}
			return rez;
		}
		else
		{
			cout << "Ошибка! Не совподают размерности матриц!";
			return Matrix(0, 0);
		}


	}
	Matrix mult(Matrix M2)
	{
		if (M == M2.N)
		{
			Matrix rez(N, M2.M);
			for (int i = 0; i < N; i++) //строки(цикл)
			{
				for (int j = 0; j < M2.M; j++) //столцы(цикл)
				{
					double s = 0;
					for (int r = 0; r < M; r++)
					{
						s += mas[i][r] * M2.mas[r][j];
					}
					rez.mas[i][j] = s;
				}

			}
			return rez;
		}
		else
		{
			cout << "Ошибка! Кол-во строк Матрицы 1 не совподает с кол-вом столбцов Матрицы 2!";
			return Matrix(0, 0);
		}


	}

public:
	int N, M;
	Matrix()
	{

	}
	Matrix(int n, int m)
	{
		N = n;
		M = m;
		mas = new double* [n]; //казываем масив
		for (int i = 0; i < n; i++) //водим значение матрицы
		{
			mas[i] = new double[m]; //для того чтобы в стону можно было вести m количество значений
		}


	}

	void input()
	{
		setlocale(LC_ALL, "Rus");
		for (int i = 0; i < N; i++) //строки(цикл)
		{
			for (int j = 0; j < M; j++) //столцы(цикл)
			{
				cout << "Введите значение ечейки в строке:  " << i << ", столбце: " << j << " "; //водится значение i и j
				cin >> mas[i][j]; //выводится значение mas[i][j]
			}

		}
	}
	void print()
	{
		for (int i = 0; i < N; i++) //строки(цикл)
		{
			for (int j = 0; j < M; j++) //столцы(цикл)
			{

				cout << mas[i][j] << "\t";
			}
			cout << endl;
		}
	}

	Matrix transp()
	{
		Matrix rez(M, N);
		for (int i = 0; i < N; i++) //строки(цикл)
		{
			for (int j = 0; j < M; j++) //столцы(цикл)
			{
				rez.mas[j][i] = mas[i][j];
			}

		}
		return rez;
	}
	Matrix operator + (Matrix M2)
	{
		return this->sum(M2);
	}
	Matrix operator - (Matrix M2)
	{
		return this->sub(M2);
	}
	Matrix operator * (Matrix M2)
	{
		return this->mult(M2);
	}
	bool operator == (Matrix M2)
	{
		for (int i = 0; i < N; i++) //строки(цикл)
		{
			for (int j = 0; j < M; j++) //столцы(цикл)
			{
				if (mas[i][j] != M2.mas[i][j])
				{
					return false;
				}
			}

		}
		return true;
	}
	Matrix operator = (Matrix M2)
	{

		N = M2.N;
		M = M2.M;
		mas = new double* [N]; //казываем масив
		for (int i = 0; i < N; i++) //водим значение матрицы
		{
			mas[i] = new double[M]; //для того чтобы в стону можно было вести m количество значений
		}


		for (int i = 0; i < N; i++) //строки(цикл)
		{
			for (int j = 0; j < M; j++) //столцы(цикл)
			{
				this->mas[i][j] = M2.mas[i][j];
			}

		}
		return *this;
	}
	Matrix(Matrix* M2)
	{
		N = M2->N;
		M = M2->M;
		mas = new double* [N]; //казываем масив
		for (int i = 0; i < N; i++) //водим значение матрицы
		{
			mas[i] = new double[M]; //для того чтобы в стону можно было вести m количество значений
		}

		for (int i = 0; i < N; i++) //строки(цикл)
		{
			for (int j = 0; j < M; j++) //столцы(цикл)
			{
				mas[i][j] = M2->mas[i][j];
			}
		}
	}
	double* operator [](int index1)//, int index2)
	{
		return mas[index1];
	}

};
int main()
{

	int n, m, e, r;
	cin >> n;
	cin >> m;
	Matrix M1(n, m);
	cin >> e;
	cin >> r;
	Matrix M2(e, r);
	M1.input();

	double aaa = M1[3][3];

	
	M2.input();
	cout << "sum" << endl;
	Matrix M3 = M1 + M2;
	M3.print();
	cout << "minys" << endl;
	M3 = M1 - M2;
	M3.print();
	cout << "umnoj" << endl;
	M3 = M1 * M2;
	M3.print();
	cout << "perevarachivaem" << endl;
	M3 = M1.transp();
	M3.print();
	cout << "operator kopirovania" << endl;
	Matrix M4;
	M4 = M2;
	M4.print();
	cout << "konstruktor kopirovania" << endl;
	Matrix M5 = Matrix(&M1);
	M5.print();
	system("pause");
	return 0;
}
