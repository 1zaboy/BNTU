﻿#include <iostream>

class Window
{
private:

public:

};

class Stack : Window
{
private:

public:

};

class Puff : Window
{
private:

public:

};

class PopUp : Window
{
private:

public:

};


int main()
{
	std::cout << "Hello World!\n";
	std::cout << "Main task\n";

}


